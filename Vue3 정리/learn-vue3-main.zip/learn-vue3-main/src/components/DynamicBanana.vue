<template>
	<AppCard> 바나나 </AppCard>
</template>

<script setup>
import AppCard from './AppCard.vue';
</script>
