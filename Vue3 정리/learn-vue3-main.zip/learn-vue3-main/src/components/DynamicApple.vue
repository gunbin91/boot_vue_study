<template>
	<AppCard> 사과 </AppCard>
</template>

<script setup>
import AppCard from './AppCard.vue';
</script>
