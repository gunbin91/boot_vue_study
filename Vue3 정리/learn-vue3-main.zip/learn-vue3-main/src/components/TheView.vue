<template>
	<main>
		<DynamicComponent />
	</main>
</template>

<script setup>
import DynamicComponent from './DynamicComponent.vue';
</script>

<style lang="scss" scoped></style>
